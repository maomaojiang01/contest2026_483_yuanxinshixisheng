#ifndef VELAVISION_VOICELINK_ASR_RUNTIME_H
#define VELAVISION_VOICELINK_ASR_RUNTIME_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int k7_asr_model_session_probe(void);
int k7_asr_microphone_probe(void);

/* Recognize the last completed microphone capture into caller-owned storage.
 * Returns 0 on success or a negative errno value. The destination is always
 * NUL terminated when capacity is nonzero and is cleared on every failure. */
int k7_asr_microphone_text(char *utf8_text, size_t capacity);

#ifdef __cplusplus
}
#endif

#endif
