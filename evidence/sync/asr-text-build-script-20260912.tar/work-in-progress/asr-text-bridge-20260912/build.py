"""Build the bounded ASR text bridge and a separate RK3576 RAM image."""

import hashlib
import json
import os
import subprocess
from pathlib import Path


HERE = Path(__file__).resolve().parent
PROJECT = Path("/home/swl/openvela/work/velavision-project")
SDK = Path("/home/swl/openvela")
ASR_PRIOR = Path("/home/swl/openvela/work/native-asr-recognizer")
TLS_PRIOR = Path("/home/swl/openvela/work/native-emutls-fix")
BUILD = SDK / "cmake_out/velavision_voice_asr_text_20260912"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(command, log, timeout, cwd=None, env=None):
    with log.open("wb") as output:
        result = subprocess.run(
            command,
            cwd=str(cwd) if cwd else None,
            env=env,
            stdout=output,
            stderr=subprocess.STDOUT,
            timeout=timeout,
        )
    return result.returncode


def main():
    expected = json.loads((HERE / "inputs.json").read_text(encoding="utf-8"))
    for relative, digest in expected.items():
        path = PROJECT / relative
        if sha(path) != digest:
            raise RuntimeError("input hash changed: " + relative)
    if BUILD.exists():
        raise RuntimeError("refusing to reuse build directory: " + str(BUILD))

    compile_base = json.loads(
        (ASR_PRIOR / "compile-attempt2.json").read_text(encoding="utf-8")
    )["command"]
    objects = []
    compile_records = []
    sources = [
        PROJECT / "app/voicelink/src/native_asr_runtime.cpp",
        TLS_PRIOR / "tls_probe.cpp",
        TLS_PRIOR / "emutls.c",
    ]
    for source in sources:
        obj = HERE / (source.name + ".o")
        command = list(compile_base)
        command[command.index("-c") + 1] = str(source)
        command[command.index("-o") + 1] = str(obj)
        command += ["-I" + str(ASR_PRIOR)]
        if source.suffix == ".c":
            command = [x for x in command if not x.startswith("-std=") and x != "-nostdinc++"]
            command[0] = command[0].replace("-g++", "-gcc")
        exit_code = run(command, HERE / (source.name + ".log"), 180)
        compile_records.append({"source": str(source), "command": command, "exit_code": exit_code})
        if exit_code:
            raise RuntimeError("compile failed: " + source.name)
        objects.append(obj)

    prior_link = json.loads(
        (ASR_PRIOR / "link2/result.json").read_text(encoding="utf-8")
    )["link_command"]
    runtime = HERE / "runtime.o"
    link = list(prior_link)
    link[link.index("-o") + 1] = str(runtime)
    old_probe = str(ASR_PRIOR / "link2/recognizer_probe.cpp.o")
    link = [str(objects[0]) if item == old_probe else item for item in link]
    link += [str(objects[1]), str(objects[2])]
    link_exit = run(link, HERE / "link.log", 300)
    if link_exit:
        raise RuntimeError("relocatable runtime link failed")
    runtime_hash = sha(runtime)

    configure = [
        "cmake", "-S", "nuttx", "-B", str(BUILD), "-G", "Ninja",
        "-DBOARD_CONFIG=kickpi_k7:velavision_audio_sound_local",
        "-DK7VOICE_NATIVE_ORT_ADD=ON",
        "-DK7VOICE_NATIVE_ASR_MODEL=ON",
        "-DK7VOICE_NATIVE_ASR_MIC=ON",
        "-DK7VOICE_ORT_OBJECT=" + str(runtime),
        "-DK7VOICE_ORT_OBJECT_SHA256=" + runtime_hash,
    ]
    environment = dict(os.environ)
    toolchain = str(SDK / "prebuilts/gcc/linux-x86_64/aarch64-none-elf/bin")
    environment["PATH"] = toolchain + os.pathsep + environment.get("PATH", "")
    configure_exit = run(configure, HERE / "configure.log", 600, SDK, environment)
    if configure_exit:
        raise RuntimeError("firmware configure failed")
    build_command = ["cmake", "--build", str(BUILD), "-j4"]
    build_exit = run(build_command, HERE / "build.log", 2400, SDK, environment)

    result = {
        "runtime_sha256": runtime_hash,
        "compile": compile_records,
        "link_command": link,
        "link_exit_code": link_exit,
        "configure_command": configure,
        "configure_exit_code": configure_exit,
        "build_command": build_command,
        "build_exit_code": build_exit,
        "inputs": expected,
        "board_tested": False,
    }
    if build_exit == 0:
        result["artifacts"] = {
            name: {
                "bytes": (BUILD / name).stat().st_size,
                "sha256": sha(BUILD / name),
            }
            for name in ("nuttx", "nuttx.bin", ".config")
        }
    (HERE / "result.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2), flush=True)
    if build_exit:
        raise SystemExit(build_exit)


if __name__ == "__main__":
    main()
